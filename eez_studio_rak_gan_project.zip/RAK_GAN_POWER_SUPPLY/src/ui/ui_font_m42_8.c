/*******************************************************************************
 * Size: 8 px
 * Bpp: 1
 * Opts: --bpp 1 --size 8 --no-compress --font ..\..\Desktop\pixel fonts\m42flight721\m42.TTF --range 32-127 --format lvgl
 ******************************************************************************/

#ifdef __has_include
    #if __has_include("lvgl.h")
        #ifndef LV_LVGL_H_INCLUDE_SIMPLE
            #define LV_LVGL_H_INCLUDE_SIMPLE
        #endif
    #endif
#endif

#ifdef LV_LVGL_H_INCLUDE_SIMPLE
    #include "lvgl.h"
#else
    #include "lvgl.h"
#endif

#ifndef UI_FONT_M42_8
#define UI_FONT_M42_8 1
#endif

#if UI_FONT_M42_8

/*-----------------
 *    BITMAPS
 *----------------*/

/*Store the image of the glyphs*/
static LV_ATTRIBUTE_LARGE_CONST const uint8_t glyph_bitmap[] = {
    /* U+0020 " " */
    0x0,

    /* U+0021 "!" */
    0xff, 0xfe, 0x3f,

    /* U+0022 "\"" */
    0xde, 0xf6,

    /* U+0023 "#" */
    0x66, 0xff, 0xff, 0x66, 0x66, 0xff, 0xff, 0x66,

    /* U+0024 "$" */
    0x7f, 0xff, 0xd8, 0xfe, 0x7f, 0x1b, 0xff, 0xfe,

    /* U+0025 "%" */
    0x71, 0xbe, 0xed, 0xf3, 0xfe, 0x7f, 0xcf, 0xb7,
    0x7d, 0x8e,

    /* U+0026 "&" */
    0x3f, 0xf, 0xf1, 0xce, 0x3e, 0xf, 0xfd, 0xdf,
    0xbf, 0xfb, 0xf7,

    /* U+0027 "'" */
    0xfc,

    /* U+0028 "(" */
    0x7f, 0xcc, 0xcc, 0xf7,

    /* U+0029 ")" */
    0xef, 0x33, 0x33, 0xfe,

    /* U+002A "*" */
    0x18, 0xdb, 0xff, 0x7e, 0x7e, 0xff, 0xdb, 0x18,

    /* U+002B "+" */
    0x18, 0x18, 0x18, 0xff, 0xff, 0x18, 0x18, 0x18,

    /* U+002C "," */
    0xf4,

    /* U+002D "-" */
    0xff, 0xff,

    /* U+002E "." */
    0xf0,

    /* U+002F "/" */
    0x18, 0xcc, 0x66, 0x33, 0x18,

    /* U+0030 "0" */
    0x7f, 0xbf, 0xfe, 0x1f, 0x87, 0xe1, 0xf8, 0x7f,
    0xfd, 0xfe,

    /* U+0031 "1" */
    0x3b, 0xff, 0xf3, 0x9c, 0xe7,

    /* U+0032 "2" */
    0xff, 0xbf, 0xf0, 0x1d, 0xff, 0xff, 0xb8, 0xf,
    0xff, 0xff,

    /* U+0033 "3" */
    0x7f, 0xbf, 0xfe, 0x1c, 0x3e, 0xf, 0xf8, 0x7f,
    0xfd, 0xfe,

    /* U+0034 "4" */
    0xf, 0x87, 0xe3, 0xf9, 0xee, 0xf3, 0xbf, 0xff,
    0xfc, 0xe,

    /* U+0035 "5" */
    0xff, 0xff, 0xfe, 0x3, 0xfe, 0xff, 0xc0, 0x7f,
    0xff, 0xfe,

    /* U+0036 "6" */
    0x7f, 0xff, 0xfe, 0x3, 0xfe, 0xff, 0xf8, 0x7f,
    0xfd, 0xfe,

    /* U+0037 "7" */
    0xff, 0xff, 0xf0, 0x3c, 0x1e, 0xf, 0x7, 0x83,
    0xc0, 0xe0,

    /* U+0038 "8" */
    0x7f, 0xbf, 0xfe, 0x1d, 0xfe, 0xff, 0xf8, 0x7f,
    0xfd, 0xfe,

    /* U+0039 "9" */
    0x7f, 0xbf, 0xfe, 0x1f, 0xff, 0x7f, 0xc0, 0x7f,
    0xff, 0xfe,

    /* U+003A ":" */
    0xf0, 0xf0,

    /* U+003B ";" */
    0xf0, 0xf4,

    /* U+003C "<" */
    0x19, 0xdd, 0xce, 0x38, 0xe3,

    /* U+003D "=" */
    0xff, 0xff, 0x0, 0x0, 0xff, 0xff,

    /* U+003E ">" */
    0xc7, 0x1c, 0x73, 0xbb, 0x98,

    /* U+003F "?" */
    0x7f, 0xbf, 0xfe, 0x1c, 0x3f, 0xf, 0x80, 0x0,
    0xe0, 0x38,

    /* U+0040 "@" */
    0x3e, 0x3f, 0xb8, 0xf9, 0xfd, 0xfe, 0xcf, 0xe6,
    0xfc, 0x3e, 0x0,

    /* U+0041 "A" */
    0x1f, 0x3, 0xe0, 0xee, 0x1d, 0xc7, 0x1c, 0xff,
    0xbf, 0xff, 0x7,

    /* U+0042 "B" */
    0xff, 0xdf, 0xff, 0x83, 0xff, 0xef, 0xff, 0xc1,
    0xff, 0xff, 0xfe,

    /* U+0043 "C" */
    0x7f, 0xdf, 0xff, 0x83, 0xf0, 0xe, 0x1, 0xc1,
    0xff, 0xfb, 0xfe,

    /* U+0044 "D" */
    0xff, 0xdf, 0xff, 0x83, 0xf0, 0x7e, 0xf, 0xc1,
    0xff, 0xff, 0xfe,

    /* U+0045 "E" */
    0xff, 0xff, 0xff, 0x80, 0x7f, 0xef, 0xfd, 0xc0,
    0x3f, 0xff, 0xff,

    /* U+0046 "F" */
    0xff, 0xff, 0xff, 0x80, 0x7f, 0xef, 0xfd, 0xc0,
    0x38, 0x7, 0x0,

    /* U+0047 "G" */
    0x7f, 0xff, 0xff, 0x80, 0x73, 0xfe, 0x7f, 0xc1,
    0xff, 0xfb, 0xfe,

    /* U+0048 "H" */
    0xe0, 0xfc, 0x1f, 0x83, 0xff, 0xff, 0xff, 0xc1,
    0xf8, 0x3f, 0x7,

    /* U+0049 "I" */
    0xff, 0xff, 0xff,

    /* U+004A "J" */
    0x0, 0xe0, 0x1c, 0x3, 0x80, 0x7e, 0xf, 0xc1,
    0xff, 0xfb, 0xfe,

    /* U+004B "K" */
    0xe0, 0xfc, 0x7f, 0xbe, 0x7f, 0xf, 0xe1, 0xdf,
    0x38, 0xff, 0x7,

    /* U+004C "L" */
    0xe0, 0x1c, 0x3, 0x80, 0x70, 0xe, 0x1, 0xc0,
    0x3f, 0xff, 0xff,

    /* U+004D "M" */
    0xf8, 0xff, 0xc7, 0xff, 0x7f, 0xfb, 0xfe, 0xfb,
    0xf7, 0xdf, 0x9c, 0xfc, 0xe7,

    /* U+004E "N" */
    0xf0, 0xff, 0x1f, 0xf3, 0xff, 0x7e, 0xff, 0xcf,
    0xf8, 0xff, 0xf,

    /* U+004F "O" */
    0x7f, 0xdf, 0xff, 0x83, 0xf0, 0x7e, 0xf, 0xc1,
    0xff, 0xfb, 0xfe,

    /* U+0050 "P" */
    0xff, 0xdf, 0xff, 0x83, 0xf0, 0x7f, 0xff, 0xff,
    0xb8, 0x7, 0x0,

    /* U+0051 "Q" */
    0x7f, 0xcf, 0xfe, 0xe0, 0xee, 0xe, 0xe3, 0xee,
    0x3e, 0xff, 0xf7, 0xff,

    /* U+0052 "R" */
    0xff, 0xdf, 0xff, 0x83, 0xf0, 0x7f, 0xff, 0xff,
    0xb8, 0x3f, 0x7,

    /* U+0053 "S" */
    0x7f, 0xff, 0xff, 0x80, 0x7f, 0xe7, 0xfe, 0x1,
    0xff, 0xff, 0xfe,

    /* U+0054 "T" */
    0xff, 0xff, 0xfc, 0x38, 0x7, 0x0, 0xe0, 0x1c,
    0x3, 0x80, 0x70,

    /* U+0055 "U" */
    0xe0, 0xfc, 0x1f, 0x83, 0xf0, 0x7e, 0xf, 0xc1,
    0xff, 0xfb, 0xfe,

    /* U+0056 "V" */
    0xe0, 0xfc, 0x1d, 0xc7, 0x38, 0xe3, 0xb8, 0x77,
    0x7, 0xc0, 0xf8,

    /* U+0057 "W" */
    0xe3, 0x8f, 0xc7, 0x1d, 0xdf, 0x73, 0xbe, 0xe3,
    0xef, 0x87, 0xdf, 0x7, 0x1c, 0xe, 0x38,

    /* U+0058 "X" */
    0xe0, 0xfe, 0x3d, 0xef, 0x1f, 0xc3, 0xf8, 0xf7,
    0xbc, 0x7f, 0x7,

    /* U+0059 "Y" */
    0xe0, 0xfe, 0x3d, 0xef, 0x1f, 0xc1, 0xf0, 0x1c,
    0x3, 0x80, 0x70,

    /* U+005A "Z" */
    0xff, 0xff, 0xfc, 0xf, 0x87, 0xc3, 0xe1, 0xf0,
    0x3f, 0xff, 0xff,

    /* U+005B "[" */
    0xff, 0xcc, 0xcc, 0xff,

    /* U+005C "\\" */
    0xc6, 0x18, 0xc3, 0x18, 0x63,

    /* U+005D "]" */
    0xff, 0x33, 0x33, 0xff,

    /* U+005E "^" */
    0x31, 0xef, 0xf3,

    /* U+005F "_" */
    0xff, 0xf0,

    /* U+0060 "`" */
    0xdd, 0x80,

    /* U+0061 "a" */
    0x1f, 0x3, 0xe0, 0xee, 0x1d, 0xc7, 0x1c, 0xff,
    0xbf, 0xff, 0x7,

    /* U+0062 "b" */
    0xff, 0xdf, 0xff, 0x83, 0xff, 0xef, 0xff, 0xc1,
    0xff, 0xff, 0xfe,

    /* U+0063 "c" */
    0x7f, 0xdf, 0xff, 0x83, 0xf0, 0xe, 0x1, 0xc1,
    0xff, 0xfb, 0xfe,

    /* U+0064 "d" */
    0xff, 0xdf, 0xff, 0x83, 0xf0, 0x7e, 0xf, 0xc1,
    0xff, 0xff, 0xfe,

    /* U+0065 "e" */
    0xff, 0xff, 0xff, 0x80, 0x7f, 0xef, 0xfd, 0xc0,
    0x3f, 0xff, 0xff,

    /* U+0066 "f" */
    0xff, 0xff, 0xff, 0x80, 0x7f, 0xef, 0xfd, 0xc0,
    0x38, 0x7, 0x0,

    /* U+0067 "g" */
    0x7f, 0xff, 0xff, 0x80, 0x73, 0xfe, 0x7f, 0xc1,
    0xff, 0xfb, 0xfe,

    /* U+0068 "h" */
    0xe0, 0xfc, 0x1f, 0x83, 0xff, 0xff, 0xff, 0xc1,
    0xf8, 0x3f, 0x7,

    /* U+0069 "i" */
    0xff, 0xff, 0xff,

    /* U+006A "j" */
    0x0, 0xe0, 0x1c, 0x3, 0x80, 0x7e, 0xf, 0xc1,
    0xff, 0xfb, 0xfe,

    /* U+006B "k" */
    0xe0, 0xfc, 0x7f, 0xbe, 0x7f, 0xf, 0xe1, 0xdf,
    0x38, 0xff, 0x7,

    /* U+006C "l" */
    0xe0, 0x1c, 0x3, 0x80, 0x70, 0xe, 0x1, 0xc0,
    0x3f, 0xff, 0xff,

    /* U+006D "m" */
    0xf8, 0xff, 0xc7, 0xff, 0x7f, 0xfb, 0xfe, 0xfb,
    0xf7, 0xdf, 0x9c, 0xfc, 0xe7,

    /* U+006E "n" */
    0xf0, 0xff, 0x1f, 0xf3, 0xff, 0x7e, 0xff, 0xcf,
    0xf8, 0xff, 0xf,

    /* U+006F "o" */
    0x7f, 0xdf, 0xff, 0x83, 0xf0, 0x7e, 0xf, 0xc1,
    0xff, 0xfb, 0xfe,

    /* U+0070 "p" */
    0xff, 0xdf, 0xff, 0x83, 0xf0, 0x7f, 0xff, 0xff,
    0xb8, 0x7, 0x0,

    /* U+0071 "q" */
    0x7f, 0xcf, 0xfe, 0xe0, 0xee, 0xe, 0xe3, 0xee,
    0x3e, 0xff, 0xf7, 0xff,

    /* U+0072 "r" */
    0xff, 0xdf, 0xff, 0x83, 0xf0, 0x7f, 0xff, 0xff,
    0xb8, 0x3f, 0x7,

    /* U+0073 "s" */
    0x7f, 0xff, 0xff, 0x80, 0x7f, 0xe7, 0xfe, 0x1,
    0xff, 0xff, 0xfe,

    /* U+0074 "t" */
    0xff, 0xff, 0xfc, 0x38, 0x7, 0x0, 0xe0, 0x1c,
    0x3, 0x80, 0x70,

    /* U+0075 "u" */
    0xe0, 0xfc, 0x1f, 0x83, 0xf0, 0x7e, 0xf, 0xc1,
    0xff, 0xfb, 0xfe,

    /* U+0076 "v" */
    0xe0, 0xfc, 0x1d, 0xc7, 0x38, 0xe3, 0xb8, 0x77,
    0x7, 0xc0, 0xf8,

    /* U+0077 "w" */
    0xe3, 0x8f, 0xc7, 0x1d, 0xdf, 0x73, 0xbe, 0xe3,
    0xef, 0x87, 0xdf, 0x7, 0x1c, 0xe, 0x38,

    /* U+0078 "x" */
    0xe0, 0xfe, 0x3d, 0xef, 0x1f, 0xc3, 0xf8, 0xf7,
    0xbc, 0x7f, 0x7,

    /* U+0079 "y" */
    0xe0, 0xfe, 0x3d, 0xef, 0x1f, 0xc1, 0xf0, 0x1c,
    0x3, 0x80, 0x70,

    /* U+007A "z" */
    0xff, 0xff, 0xfc, 0xf, 0x87, 0xc3, 0xe1, 0xf0,
    0x3f, 0xff, 0xff,

    /* U+007B "{" */
    0x37, 0x66, 0xc6, 0x67, 0x30,

    /* U+007C "|" */
    0xff, 0xff,

    /* U+007D "}" */
    0xce, 0x66, 0x36, 0x6e, 0xc0,

    /* U+007E "~" */
    0x77, 0xff, 0x70
};

/*---------------------
 *  GLYPH DESCRIPTION
 *--------------------*/

static const lv_font_fmt_txt_glyph_dsc_t glyph_dsc[] = {
    {.bitmap_index = 0, .adv_w = 0, .box_w = 0, .box_h = 0, .ofs_x = 0, .ofs_y = 0} /* id = 0 reserved */,
    {.bitmap_index = 0, .adv_w = 96, .box_w = 1, .box_h = 1, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1, .adv_w = 64, .box_w = 3, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 4, .adv_w = 96, .box_w = 5, .box_h = 3, .ofs_x = 0, .ofs_y = 5},
    {.bitmap_index = 6, .adv_w = 144, .box_w = 8, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 14, .adv_w = 144, .box_w = 8, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 22, .adv_w = 176, .box_w = 10, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 32, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 43, .adv_w = 48, .box_w = 2, .box_h = 3, .ofs_x = 0, .ofs_y = 5},
    {.bitmap_index = 44, .adv_w = 80, .box_w = 4, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 48, .adv_w = 80, .box_w = 4, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 52, .adv_w = 144, .box_w = 8, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 60, .adv_w = 144, .box_w = 8, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 68, .adv_w = 48, .box_w = 2, .box_h = 3, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 69, .adv_w = 144, .box_w = 8, .box_h = 2, .ofs_x = 0, .ofs_y = 3},
    {.bitmap_index = 71, .adv_w = 48, .box_w = 2, .box_h = 2, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 72, .adv_w = 96, .box_w = 5, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 77, .adv_w = 176, .box_w = 10, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 87, .adv_w = 96, .box_w = 5, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 92, .adv_w = 176, .box_w = 10, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 102, .adv_w = 176, .box_w = 10, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 112, .adv_w = 176, .box_w = 10, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 122, .adv_w = 176, .box_w = 10, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 132, .adv_w = 176, .box_w = 10, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 142, .adv_w = 176, .box_w = 10, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 152, .adv_w = 176, .box_w = 10, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 162, .adv_w = 176, .box_w = 10, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 172, .adv_w = 48, .box_w = 2, .box_h = 6, .ofs_x = 0, .ofs_y = 1},
    {.bitmap_index = 174, .adv_w = 48, .box_w = 2, .box_h = 7, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 176, .adv_w = 96, .box_w = 5, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 181, .adv_w = 144, .box_w = 8, .box_h = 6, .ofs_x = 0, .ofs_y = 1},
    {.bitmap_index = 187, .adv_w = 96, .box_w = 5, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 192, .adv_w = 176, .box_w = 10, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 202, .adv_w = 160, .box_w = 9, .box_h = 9, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 213, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 224, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 235, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 246, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 257, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 268, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 279, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 290, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 301, .adv_w = 64, .box_w = 3, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 304, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 315, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 326, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 337, .adv_w = 224, .box_w = 13, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 350, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 361, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 372, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 383, .adv_w = 208, .box_w = 12, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 395, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 406, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 417, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 428, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 439, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 450, .adv_w = 256, .box_w = 15, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 465, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 476, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 487, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 498, .adv_w = 80, .box_w = 4, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 502, .adv_w = 96, .box_w = 5, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 507, .adv_w = 80, .box_w = 4, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 511, .adv_w = 112, .box_w = 6, .box_h = 4, .ofs_x = 0, .ofs_y = 4},
    {.bitmap_index = 514, .adv_w = 112, .box_w = 6, .box_h = 2, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 516, .adv_w = 64, .box_w = 3, .box_h = 3, .ofs_x = 0, .ofs_y = 5},
    {.bitmap_index = 518, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 529, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 540, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 551, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 562, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 573, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 584, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 595, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 606, .adv_w = 64, .box_w = 3, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 609, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 620, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 631, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 642, .adv_w = 224, .box_w = 13, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 655, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 666, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 677, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 688, .adv_w = 208, .box_w = 12, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 700, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 711, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 722, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 733, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 744, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 755, .adv_w = 256, .box_w = 15, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 770, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 781, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 792, .adv_w = 192, .box_w = 11, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 803, .adv_w = 80, .box_w = 4, .box_h = 9, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 808, .adv_w = 48, .box_w = 2, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 810, .adv_w = 80, .box_w = 4, .box_h = 9, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 815, .adv_w = 128, .box_w = 7, .box_h = 3, .ofs_x = 0, .ofs_y = 3}
};

/*---------------------
 *  CHARACTER MAPPING
 *--------------------*/

/*Collect the unicode lists and glyph_id offsets*/
static const lv_font_fmt_txt_cmap_t cmaps[] =
{
    {
        .range_start = 32, .range_length = 95, .glyph_id_start = 1,
        .unicode_list = NULL, .glyph_id_ofs_list = NULL, .list_length = 0, .type = LV_FONT_FMT_TXT_CMAP_FORMAT0_TINY
    }
};

/*--------------------
 *  ALL CUSTOM DATA
 *--------------------*/

#if LVGL_VERSION_MAJOR == 8
/*Store all the custom data of the font*/
static  lv_font_fmt_txt_glyph_cache_t cache;
#endif

#if LVGL_VERSION_MAJOR >= 8
static const lv_font_fmt_txt_dsc_t font_dsc = {
#else
static lv_font_fmt_txt_dsc_t font_dsc = {
#endif
    .glyph_bitmap = glyph_bitmap,
    .glyph_dsc = glyph_dsc,
    .cmaps = cmaps,
    .kern_dsc = NULL,
    .kern_scale = 0,
    .cmap_num = 1,
    .bpp = 1,
    .kern_classes = 0,
    .bitmap_format = 0,
#if LVGL_VERSION_MAJOR == 8
    .cache = &cache
#endif
};

/*-----------------
 *  PUBLIC FONT
 *----------------*/

/*Initialize a public general font descriptor*/
#if LVGL_VERSION_MAJOR >= 8
const lv_font_t ui_font_m42_8 = {
#else
lv_font_t ui_font_m42_8 = {
#endif
    .get_glyph_dsc = lv_font_get_glyph_dsc_fmt_txt,    /*Function pointer to get glyph's data*/
    .get_glyph_bitmap = lv_font_get_bitmap_fmt_txt,    /*Function pointer to get glyph's bitmap*/
    .line_height = 9,          /*The maximum line height required by the font*/
    .base_line = 1,             /*Baseline measured from the bottom of the line*/
#if !(LVGL_VERSION_MAJOR == 6 && LVGL_VERSION_MINOR == 0)
    .subpx = LV_FONT_SUBPX_NONE,
#endif
#if LV_VERSION_CHECK(7, 4, 0) || LVGL_VERSION_MAJOR >= 8
    .underline_position = -1,
    .underline_thickness = 0,
#endif
    .dsc = &font_dsc,          /*The custom font data. Will be accessed by `get_glyph_bitmap/dsc` */
#if LV_VERSION_CHECK(8, 2, 0) || LVGL_VERSION_MAJOR >= 9
    .fallback = NULL,
#endif
    .user_data = NULL,
};

#endif /*#if UI_FONT_M42_8*/